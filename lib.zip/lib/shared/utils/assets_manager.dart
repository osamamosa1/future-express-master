const String imgPath = 'assets/images';

class ImgAssets {
  static const String logo = 'assets/icons/logo.jpeg';
  static const String profile = 'assets/images/user-multiple.png';
  static const String support = 'assets/images/support.png';
  static const String wallet = 'assets/images/wallet.png';
  static const String orders = 'assets/images/order.png';
}
