class AppStrings {
  static const String appName = 'future express';
  static const String token = 'token';
}
